package TallerArreglos;

public class Punto3 {
    public static void main(String[] args) {
      int x ;

      x=1000;

        for (int i = 1; i <x ; i++) {
            System.out.println(i);
        }
    }
}
