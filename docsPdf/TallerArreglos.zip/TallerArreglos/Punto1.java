package TallerArreglos;

public class Punto1 {
    public static void main(String[] args) {
        int [] numeros = new int [5];

        numeros[0]=55;
        numeros[1]=99;
        numeros[2]=11;
        numeros[3]=56;
        numeros[4]=69;

        for (int i = 0; i < 5; i++) {
            System.out.println(numeros[i]);

        }



    }
}
