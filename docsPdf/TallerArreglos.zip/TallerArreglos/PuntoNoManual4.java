package TallerArreglos;

import javax.swing.*;
import java.util.Scanner;

public class PuntoNoManual4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int matriz [] [], nFilas, nColumnas;

        nFilas= Integer.parseInt(JOptionPane.showInputDialog("DIGITE NUMERO DE FILAS"));
        nColumnas = Integer.parseInt(JOptionPane.showInputDialog("DIGITE NUMERO DE COLUMNAS"));

        matriz = new int [nFilas][nColumnas];

        for (int i = 0; i <nFilas ; i++) {
            for (int j = 0; j <nColumnas ; j++) {
                System.out.println("DIGITE LA MATRIZ ["+i+"]["+j+"]");
                matriz[i][j]= scanner.nextInt();

            }
        }
        System.out.println(" ******* ");

        for (int i = 0; i <nFilas ; i++) { // filas
            for (int j = 0; j <nColumnas ; j++) {// columnas
                System.out.print(matriz[i][j]);
            }
            System.out.println(" ");

        }

    }

}



