package TallerArreglos;

import java.util.Scanner;

public class PuntoManual4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       int matriz [] [] = {{01,02,03,04,05,},{06,07,8,9,10},{11,12,13,14,15},{16,17,18,19,20}};

        for (int i = 0; i <5 ; i++) { // filas
            for (int j = 0; j <5 ; j++) {// columnas
                System.out.print(matriz[i][j]);
            }
            System.out.println(" ");

        }

        }

        }



