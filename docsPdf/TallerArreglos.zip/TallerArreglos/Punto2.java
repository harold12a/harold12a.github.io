package TallerArreglos;

public class Punto2 {
    public static void main(String[] args) {
        int  numeros;
        numeros=100;

        for (int i = 1; i < numeros; i++) {
            System.out.println(i);
        }

        for (int i = 1; i <10 ; i++) {
            if(i%2==0){
                System.out.println("NUMEROS PARES: "+i);
                System.out.println();

            }else{
                System.out.println("NUMEROS IMPARES: "+i);
            }
        }



    }
}
