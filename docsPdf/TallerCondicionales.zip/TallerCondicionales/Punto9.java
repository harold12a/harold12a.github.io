package TallerCondicionales;

import javax.swing.*;

public class Punto9 {
    public static void main(String[] args) {
        int opciones;

        float Rbas, Ralt,Tbas,Talt,Mabas,mbas,Tralt, Area1,Area2,Area3;

        opciones = Integer.parseInt(JOptionPane.showInputDialog("""
                        elige la figura geometrica para calcualar el area:\s
                         1- Rectangulo\s
                         2- Triangulo\s
                         3- Trapecio\s
                        """
                ));
        switch (opciones) {
            case 1 -> {
                Rbas = Float.parseFloat(JOptionPane.showInputDialog(" ingrese el valor de la base en cm: "));
                Ralt = Float.parseFloat(JOptionPane.showInputDialog("ingrese el valor de la altura en cm:"));
                Area1 = Rbas + Ralt;
                JOptionPane.showMessageDialog(null, "el area del Rectangulo  es: " + Area1 + "cm*2");
            }
            case 2 -> {
                Tbas = Float.parseFloat(JOptionPane.showInputDialog(" ingrese el valor de la base en cm: "));
                Talt = Float.parseFloat(JOptionPane.showInputDialog("ingrese el valor de la altura en cm:"));
                Area2 = (Tbas + Talt) / 2;
                JOptionPane.showMessageDialog(null, "el area del triangulo es: " + Area2 + "cm*2");
            }
            case 3 -> {
                Mabas = Float.parseFloat(JOptionPane.showInputDialog(" ingrese el valor de la base mayor en cm: "));
                mbas = Float.parseFloat(JOptionPane.showInputDialog("ingrese el valor de la base menor en cm:"));
                Tralt = Float.parseFloat(JOptionPane.showInputDialog("ingrese el valor de la altura en  cm:"));
                Area3 = (Mabas + mbas) * (Tralt / 2);
                JOptionPane.showMessageDialog(null, "el area del trapecio es: " + Area3 + "cm*2");
            }
        }


    }
}
