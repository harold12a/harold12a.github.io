package TallerCondicionales;

import javax.swing.*;


public class Punto10 {
    public static void main(String[] args) {

        final int cantidad = 1000;
        int opcion;
        float ingreso, saldoActual = cantidad, retiro;

        opcion = Integer.parseInt(JOptionPane.showInputDialog("""
                bienvenidos a su Banco fiel\s
                 1- ingresar dinero\s
                 2- retirar dinero\s
                 3- consular saldo\s
                 4- Salir"""));

        switch (opcion){
            case 1: ingreso = Float.parseFloat(JOptionPane.showInputDialog(" Digite la cantidad que desea ingresar: "));
            saldoActual = cantidad + ingreso;
            JOptionPane.showMessageDialog(null,"Dinero actual: "+saldoActual);
            break;
            case 2: retiro = Float.parseFloat(JOptionPane.showInputDialog("Dijite la cantidad a retirar: "));
            if(retiro>cantidad){
                JOptionPane.showMessageDialog(null,"saldo no disponible para la cantidad: ");
            }else {
                saldoActual = cantidad - retiro;
                JOptionPane.showMessageDialog(null,"Dinero en cuenta: "+saldoActual);
            }
            break;
            case 3 : JOptionPane.showMessageDialog(null,"su saldo actual es: "+ saldoActual);
            break;
            case 4:break;
            default:JOptionPane.showMessageDialog(null,"no esta la opcion en el menu");
        }

    }
}
