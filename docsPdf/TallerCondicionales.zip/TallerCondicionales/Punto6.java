package TallerCondicionales;

import javax.swing.*;
import java.util.Scanner;


public class Punto6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        int opcion;


        opcion = Integer.parseInt(JOptionPane.showInputDialog("bienvenidos al taller EL MAQUINISTA \n"
                + " 1- ingreso al taller \n"
                + " 2- observaciones \n"
                + " 3- arreglos realizados \n"
                + " 4- Salir del taller con las novedades"));

        switch (opcion){
            case 1: System.out.println("ingreso al taller EL MAQUINISTA");
                System.out.println("estado de la moto 1-10: ");
                String estado = scanner.nextLine();
                System.out.println("dia de ingreso: ");
                String dia = scanner.nextLine();
                System.out.println("propietario: ");
                String dueño = scanner.nextLine();
                System.out.println("------*******-----");
                System.out.println("el estado de su moto es: "+estado+ "\n"
                        + " ingresando el dia: " + dia + "\n"
                        + " propietario de la moto: "+ dueño);
                System.out.println("------********-----");
                break;
            case 2: System.out.println("observaciones taller EL MAQUINISTA");
                System.out.println(" observaciones de la  moto: ");
                String observaciones = scanner.nextLine();

                System.out.println("------*******-----");
                System.out.println("informe de la moto: "+observaciones+ "\n"
                        + " gracias por preferirnos");
                System.out.println("------********-----");
                break;
            case 3 : System.out.println("ARREGLOS REALIZADOS");
                System.out.println("cambio de aceites si - no");
                String cambio = scanner.nextLine();
                System.out.println("informe del motor:");
                String motor = scanner.nextLine();
                System.out.println("arreglos extras: ");
                String extras = scanner.nextLine();
                System.out.println("------*******-----");
                System.out.println("se realizo cambio de aceite:" +cambio+" \n"
                        + " informe del motor: " +motor+" \n"
                        + " propietario de la moto:" +extras+" \n"
                        +" arreglos adicionales"
                );
                System.out.println("------********-----");
                break;
            case 4:
                System.out.println("novedades adicionales");
                String nov = scanner.nextLine();
                System.out.println(" su vehiculos presento: "+nov+ " gracias por visitarnos");

                break;
            default:JOptionPane.showMessageDialog(null,"no esta la opcion en el menu elige una opcion del 1 -4");
        }

    }
}
