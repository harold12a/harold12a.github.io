package TallerCondicionales;

import javax.swing.*;

public class Punto7 {
    public static void main(String[] args) {


        float peso, altura, imc;
        peso=Float.parseFloat(JOptionPane.showInputDialog("ingrese su peso en kg: "));
        altura=Float.parseFloat(JOptionPane.showInputDialog("ingrese su altura en mt: "));
        imc=peso/(altura*altura);
        if(imc<18.5){
            System.out.println("usted esta de bajo peso");
        }else if((imc>=18.5)&&(imc<25)){
            System.out.println("usted tiene un peso normal");
        }else if((imc>=25)&&(imc<30)){
            System.out.println("tiene sobre peso");
        }else if (imc>30) {
            System.out.println("tiene obesidad");
        }
    }
}
