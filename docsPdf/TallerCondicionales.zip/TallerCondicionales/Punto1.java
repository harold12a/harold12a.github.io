package TallerCondicionales;

import java.util.Scanner;

public class Punto1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("ingrese su edad: ");
        int edad = scanner.nextInt();

        if (edad>=18){
            System.out.println("Usted es mayo de edad ");
        }


    }
}
