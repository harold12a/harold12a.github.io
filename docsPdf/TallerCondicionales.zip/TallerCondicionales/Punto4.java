package TallerCondicionales;

import javax.swing.*;
import java.util.Scanner;

public class Punto4 {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        int numero;



        System.out.println(" 1- alquiler de peliculas ");
        System.out.println(" 2- consultar disponibilidad de peliculas");
        System.out.println(" 3- recibir pelicula en tienda");

        numero = Integer.parseInt(JOptionPane.showInputDialog(" eliga una opcion para realizar su consulta"));
        if(numero==1){
            System.out.println("las peliculas disponibles para alquiler son: ");
            System.out.println("Avatar ");
            System.out.println("fash and furios ");
            System.out.println("piratas del caribe ");
            System.out.println("indica la pelicula ha alquilar: ");
            String peliculaAlquiler = scanner.nextLine();
            System.out.println("ingresa tu nombre completo: ");
            String nombre = scanner.nextLine();
            System.out.println("has Alquilado: "+peliculaAlquiler+ " por 30 dias ");
            System.out.println(nombre+" para retirar la pelicula dirigete a la tienda.");


        }else if (numero==2){
            System.out.println("las peliculas disponibles son: ");
            System.out.println("Avatar ");
            System.out.println("fash and furios ");
            System.out.println("piratas del caribe ");
            System.out.println("ingresa tu nombre completo: ");
            String nombre = scanner.nextLine();
            System.out.println(nombre+" si quieres alquilar una pelicula escoge la opcion 1 ");

        }else if (numero==3){
            System.out.println("recibie tu pelicula en la tienda; indicanos cual es la pelicula que vas a llevar : ");
            System.out.println("Avatar ");
            System.out.println("fash and furios ");
            System.out.println("piratas del caribe ");
            System.out.println("ingresa la pelicula a recibir en la tienda: ");
            String peliculaAlquiler = scanner.nextLine();
            System.out.println(peliculaAlquiler+ " esta lista pasa por tu pelicula gracias por preferirnos");

        }else{
            System.out.println("la opcion no es valida");
        }
    }



    }

