package TallerCondicionales;


import javax.swing.*;
import java.util.Scanner;

public class Punto5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println(" elige una opcion para realizar su consulta: ");
        System.out.println(" 1- comprar producto: ");
        System.out.println(" 2- consultar valor del producto: ");
        System.out.println(" 3- devoluciones: ");
        int numero;

        numero = Integer.parseInt(JOptionPane.showInputDialog(" eliga una opcion para realizar su consulta"));

        if (numero == 1) {
            System.out.println("Dolex");
            System.out.println("Gota para los ojos");
            System.out.println("Replente");
            System.out.println("Agua");
            System.out.println("Producto Dermatologico");
            System.out.println("-----------");
            System.out.println("ingresa nombre completo: ");
            String nombre = scanner.nextLine();
            System.out.println("que medicamento deseas llevar: ");
            String medicamento = scanner.nextLine();
            System.out.println("gracias por comprar:"+medicamento+ " en nuestra localidad de suba "+nombre);
        }   else if (numero == 2){
            System.out.println("***valor de los productos***");
            System.out.println("****************************");
            System.out.println("Dolex $ 100");
            System.out.println("Gota para los ojos $200");
            System.out.println("Replente $300");
            System.out.println("Agua $50");
            System.out.println("Producto Dermatologico $500");
            System.out.println("****************************");
            System.out.println("---------------------------------");
            System.out.println("si deseas hacer una compra ingresa a la opcion 1 ");
        }else if(numero == 3){
            System.out.println("****que producto desea devolver:***** ");
            System.out.println("Dolex $ 100");
            System.out.println("Gota para los ojos $200");
            System.out.println("Replente $300");
            System.out.println("Agua $50");
            System.out.println("Producto Dermatologico $500");
            System.out.println("-----------------------------------");
            System.out.println("ingresa el producto: ");
            String producto = scanner.nextLine();
            System.out.println("El producto: "+producto+ " esta en proceso para su devoluvion:");
            System.out.println("*****gracias por preferirnos******");
        }else{
            System.out.println("opcion no valida");
        }
    }
}
