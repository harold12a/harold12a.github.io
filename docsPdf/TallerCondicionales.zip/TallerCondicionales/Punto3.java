package TallerCondicionales;

import java.util.Scanner;

public class Punto3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("ingrese su nombre:");
        String nombre = scanner.nextLine();
        System.out.println("ingrese su apellido:");
        String apellido = scanner.nextLine();
        System.out.println("ingrese su edad: ");
        int edad = scanner.nextInt();

        if (edad>=18){
            System.out.println(nombre+ " "+apellido+ " Usted es mayo de edad, por o tanto puede ingresar a la fiesta.");
        }else{
            System.out.println(nombre+ " "+apellido+ " Usted es menor de edad, por lo tanto, no puede entrar a la fiesta, por favor devuelvase para la casa");
        }


    }
}