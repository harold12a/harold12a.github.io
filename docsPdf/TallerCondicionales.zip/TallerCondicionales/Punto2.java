package TallerCondicionales;

import java.util.Scanner;

public class Punto2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("ingrese su edad: ");
        int edad = scanner.nextInt();

        if (edad<=18){
            System.out.println("usted aun es un Niño ");
        }
    }
}


