package TallerCondicionales;

import javax.swing.*;
import java.util.Scanner;

public class Punto8 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);


        int opcion;


        opcion = Integer.parseInt(JOptionPane.showInputDialog("bienvenidos a la pasteleria DON CARLOS \n"
                + " 1- REALIZAR PEDIDO \n"
                + " 2- TORTAS DISPONIBLES \n"
                + " 3- VENTAS  \n"
                + " 4- SALIR"));

        switch (opcion) {
            case 1:
                System.out.println("ingreso al taller EL MAQUINISTA");
                System.out.println("INGRESE EL SABOR DE LA TORTA: \n"
                        + " arequipe \n"
                        + " maracuya \n"
                        + " guanabana \n"
                        + " chocolate"
                        );
                String sabor = scanner.nextLine();
                System.out.println("CANTIDAD DE PORCIONES QUE QUIERE SU TORTA:\n "
                       +" 1 porcion: \n"
                       +" 2 porcion: \n"
                       +" 3 porcion: \n"
                       +"familiar"
                      );
                String porcion = scanner.nextLine();
                System.out.println("ESPECIFICA LAS DECORAACION DE LA TORTA: ");
                String especificaciones = scanner.nextLine();
                System.out.println("------*******-----");
                System.out.println(" EL SABOR DE LA TORTA ELEGIDA ES DE : " + sabor + "\n"
                        + " LA TORTA ES DE : " + porcion + "\n"
                        + " ESPECIFICACIONES: " + especificaciones);
                System.out.println("------********-----");
                break;
            case 2:
                System.out.println("PARA ENTREGA INMEDIATA TENEMOS TORTAS DE: ");
                System.out.println("maracuya con decoraciones personalidad");
                System.out.println("chocolate familiar");
                System.out.println("arequipe con lechera");
                System.out.println(" que torta deseas comprar: ");
                String torta = scanner.nextLine();

                System.out.println("------*******-----");
                System.out.println("HAS COMPRADO LA TORTA DE : " + torta + " ES LA PREFERIDAD DE NUESTRAS CLIENTELA"+ "\n"
                        + " GRACIAS POR COMPAR EN DON CARLOS TORTAS");
                System.out.println("------********-----");
                break;
            case 3:
                System.out.println("REGITRA TU COMPRA");
                System.out.println("indicanos la torta que comprastes:");
                String TOR = scanner.nextLine();
                System.out.println("cantiad:");
                String mo = scanner.nextLine();
                System.out.println("indicanos el dia: ");
                String dia = scanner.nextLine();
                System.out.println("------*******-----");
                System.out.println("TORTA DE :" + TOR + " \n"
                        + " CANTIDAD: " + mo + " \n"
                        + " FECHA :" + dia + " \n"
                        + " GRACIAS POR TU REGISTRAR TU PEDIDO TE ESPERAMOS PRONTO"
                );
                System.out.println("------********-----");
                break;
            case 4:break;


            default:
                JOptionPane.showMessageDialog(null, "no esta la opcion en el menu elige una opcion del 1 -4");
        }
    }
}
