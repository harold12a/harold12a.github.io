

package TallerCiclos;


import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Punto8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        int consultar;
        boolean condicion = true;
        int i;
        int numeroR;
        int ID;
        int resultado;
        String nombre;

        List<String> nombres = new ArrayList<>();
        List<Integer> IDS = new ArrayList<>();
        List<Integer> resultados = new ArrayList<>();


        while (condicion) {
            opcion = Integer.parseInt(JOptionPane.showInputDialog("ENSEÑANZA AUTOMOVILISTICA \n"
                    + " 1- INGRESAR AL CURSO \n"
                    + " 2- CONSULTAR USUARIO - RESULTADO DE PRUEBA\n"
                    + " 3- SALIR \n"
            ));
            switch (opcion) {
                case 1 -> {
                    System.out.println("INGRESE LA CANTIDAD DE USUARIO A REGISTRAR...");
                    numeroR = Integer.parseInt( scanner.nextLine());
                    if (numeroR <= 8) {
                        for (i = 1; i <= numeroR; i++) {
                            System.out.println("USUARIO: ");
                            nombre = scanner.nextLine().replace("\\n", "");
                            System.out.println("ID");
                            ID = Integer.parseInt( scanner.nextLine());
                            System.out.println("PUNTUACION DE LA PRUEBA DEL 0-10");
                            resultado = Integer.parseInt( scanner.nextLine());

                            nombres.add(nombre);
                            IDS.add(ID);
                            resultados.add(resultado);
                        }
                    }
                }
                case 2 -> {
                    System.out.println("CONSULTAR PRUEBA");
                    System.out.println("INGRESE EL ID");
                    consultar = Integer.parseInt( scanner.nextLine());
                    if (IDS.size()>0) {
                       for (int j = 0; j < IDS.size(); j++) {
                            if (IDS.get(j).equals(consultar)){
                                System.out.println("ID: " +IDS.get(j));
                                System.out.println(nombres.get(j) + " SU RESULTADO ES: " + resultados.get(j));
                                System.out.println("NO APROBO <7");
                                System.out.println("APROBO >=7");
                                System.out.println("PUEDES COMUNICARTE CON NOSOTROS SI TIENES INQUIETUDES # 123456789");
                            }
                        }

                    } else {
                        System.out.println("INGRESE OTRO ID PARA VALIDAR");
                    }
                }

                    case 3 -> {
                        condicion = false;
                        System.out.println("****SALISTES DEL PROGRAMA****");
                    }
                    default -> JOptionPane.showMessageDialog(null, "OPCION NO ENCONTRADA");
                }


            }
        }
    }



