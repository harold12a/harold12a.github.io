package TallerCiclos;

import javax.swing.*;
import java.util.Scanner;

public class Punto4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("ingrese el numero de la tabla mulplicar que quiere ver: ");
        int numero = scanner.nextInt();
        for (int mult = 1; mult <=10 ; mult++) {
            System.out.println(numero+ " * " +mult+ " = "+ (numero*mult));

            }
        }
    }


