package TallerCiclos;

import java.util.Scanner;

public class Punto2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n=0;
        n= scanner.nextInt();

        for (int i = 0; i < n; i++)  {// filas
            for (int j = n-1-i; j >=0;  j--){// columnas
                System.out.print("  ");
            }
            for (int j = 0; j <=i;  j++) {//{columnas
                System.out.print("* ");
            }
            System.out.println("");

        }
    }


}
