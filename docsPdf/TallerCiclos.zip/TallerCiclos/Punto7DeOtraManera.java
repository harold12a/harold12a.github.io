package TallerCiclos;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Punto7DeOtraManera {

    public static String nombre;
    public static String placa;
    public static String marca;
    public static int contacto;
    public static String retiro;
    public static String consultar;
    public static List<String> nombres = new ArrayList<>();
    public static List<String> placas = new ArrayList<>();
    public static List<String> marcas = new ArrayList<>();
    public static List<Integer> contactos = new ArrayList<>();
    public static boolean deleted = false;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        boolean condicion = true;
        int i = 0,j,k ;
        int Nrequerido;

        while (condicion) {
            opcion = Integer.parseInt(JOptionPane.showInputDialog("PARQUIADERO EL GUARDIAN  \n"
                    + " 1- INGRESAR AL PARQUIADERO \n"
                    + " 2- RETIRAR VEHICULO \n"
                    + " 3- CONSULTAR VEHICULO POR PLACA \n"
                    + " 4- SALIR"));
            switch (opcion) {
                case 1 -> {
                    System.out.println("CUANTOS USUARIOS QUIERES INGRESAR...");
                    Nrequerido = scanner.nextInt();
                    if (Nrequerido <= 5) {
                        for (i = 1; i <= Nrequerido; i++) {
                            scanner.nextLine();
                            System.out.println("USUARIO: ");
                            nombre = scanner.nextLine().replace("\\n", "");
                            System.out.println("PLACA: ");
                            placa = scanner.nextLine();
                            System.out.println("MARCA: ");
                            marca = scanner.nextLine();
                            System.out.println("CONTACTO");
                            contacto = scanner.nextInt();

                            assert nombres != null;
                            nombres.add(nombre);
                            placas.add(placa);
                            marcas.add(marca);
                            contactos.add(contacto);
                        }
                        System.out.println("HAS AGREGADO EL MAXIMO DE USUARIOS SOLITADOS...");
                    } else {
                        System.out.println("EL MAXIMO DE USUARIO ES 5 INGRESA UN VALOR INFERIOR A 5...");
                    }
                }
                case 2 -> {
                    System.out.println("RETIRAR VEHIVULO:");
                    System.out.println("INGRESE PLACA PARA EL RETIRO DE SU VEHICULO:");
                    retiro = scanner.nextLine();
                    deleted = false;
                    deleteVehicle(retiro);
                    break;
                }
                case 3 -> {
                    System.out.println("BUSQUEDA POR PLACA: ");
                    System.out.println("INGRESE LA PLACA DE SU VEHICULO:");
                    consultar = scanner.nextLine();
                    if(placas.size()>0){
                        for ( j = 0; j < placas.size(); j++) {
                            if(placas.get(j).equals(consultar)){
                                System.out.println("NOMBRE: " + nombres.get(j) + "\n"
                                        + "PLACA: " + placas.get(j) + "\n"
                                        + "MARCA: " + marcas.get(j) + "\n"
                                        + "CONTACTO: " + contactos.get(j)
                                );
                            } else{
                                System.out.println("INGRESE OTRA PLACA");
                            }

                        }
                    }

                }
                case 4 -> {
                    condicion = false;
                    System.out.println("*SALISTES DEL PROGRAMA*");
                }
                default -> JOptionPane.showMessageDialog(null, "OPCION NO ENCONTRADA");
            }

        }
    }
    public static void leftNull() {
        for (int i = 0; i < placas.size(); i++) {
            if (placas.get(i) == null) {
                for (int j = i; j < placas.size() - 1; j++) {
                    placas.set(j, placas.get(j + 1));
                    nombres.set(j, nombres.get(j + 1));
                    marcas.set(j, marcas.get(j + 1));
                    contactos.set(j, contactos.get(j + 1));
                }
                placas.set(placas.size() - 1, null);
                nombres.set(nombres.size() - 1, null);
                marcas.set(marcas.size() - 1, null);
                contactos.set(contactos.size() - 1, 0);
            }
        }
    }
    public static void deleteVehicle(String placa) {
        for (int i = 0; i < placas.size(); i++) {
            if (placas.get(i).equals(placa)) {
                placas.remove(i);
                nombres.remove(i);
                marcas.remove(i);
                contactos.remove(i);
                leftNull();
                deleted = true;
            }
            if (deleted){
                System.out.println("VEHICULO ELIMINADO");
            } else {
                System.out.println("VEHICULO NO ENCONTRADO");
            }
        }
    }
}