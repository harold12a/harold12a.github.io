package TallerCiclos;

import javax.swing.*;
import java.util.Scanner;

public class Punto6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        boolean condicion = true;

        String nombre1 = null, nombre2 = null, nombre3 = null;
        String organizacion1 = null, organizacion2 = null, organizacion3 = null;
        String SI = null;
        int buscarNumero;
        int telefono1 = 0, telefono2 = 0, telefono3 = 0;

        while (condicion) {
            opcion = Integer.parseInt(JOptionPane.showInputDialog("bienvenidos a la pasteleria DON CARLOS\n"
                    + " 1- AÑADIR CONTACTO \n"
                    + " 2- BUSCAR CONTACTO \n"
                    + " 3- ELIMINAR CONTACTO  \n"
                    + " 4- SALIR"));


            switch (opcion) {
                case 1 -> {
                    System.out.println("ingrese su nombre: 1 ");
                    nombre1 = scanner.nextLine();
                    System.out.println("ingrese su organizacion: 1");
                    organizacion1 = scanner.nextLine();
                    System.out.println("ingrese su telefono: 1 ");
                    telefono1 = scanner.nextInt();
                    System.out.println("ingrese su telefono: 2 ");
                    telefono2 = scanner.nextInt();
                    scanner.nextLine();
                    if (telefono2 == telefono1) {
                        System.out.println("el numero ya existe ingresa otro numero ");
                        telefono2 = scanner.nextInt();
                        System.out.println("ingrese su nombre: 2 ");
                        nombre2 = scanner.nextLine();
                        System.out.println("ingrese su organizacion: 2");
                        organizacion2 = scanner.nextLine();
                    } else {
                        System.out.println("ingrese su nombre: 2 ");
                        nombre2 = scanner.nextLine();
                        System.out.println("ingrese su organizacion: 2");
                        organizacion2 = scanner.nextLine();


                    }
                    System.out.println("ingrese su telefono: 3");
                    telefono3 = scanner.nextInt();
                    scanner.nextLine();
                    if ((telefono3 == telefono1) || (telefono3 == telefono2)) {
                        System.out.println("el numero ya existe ingresa otro numero");
                        telefono3 = scanner.nextInt();
                        System.out.println("ingrese su nombre: 3 ");
                        nombre3 = scanner.nextLine();
                        System.out.println("ingrese su organizacion: 3");
                        organizacion3 = scanner.nextLine();

                    } else {
                        System.out.println("ingrese su nombre: 3 ");
                        nombre3 = scanner.nextLine();
                        System.out.println("ingrese su organizacion: 3");
                        organizacion3 = scanner.nextLine();
                    }
                    System.out.println("no se puede agregar mas contactos");
                }
                case 2 -> {
                    System.out.println("ingrese numero telefonico a buscar: ");
                    buscarNumero = scanner.nextInt();
                    if (buscarNumero == telefono1) {
                        System.out.println("NOMBRE: " + nombre1);
                        System.out.println("ORGANIZACION: " + organizacion1);
                        System.out.println("CONTACTO: " + telefono1);
                    } else if (buscarNumero == telefono2) {
                        System.out.println("NOMBRE: " + nombre2);
                        System.out.println("ORGANIZACION: " + organizacion2);
                        System.out.println("CONTACTO: " + telefono2);

                    } else if (buscarNumero == telefono3) {
                        System.out.println("NOMBRE: " + nombre3);
                        System.out.println("ORGANIZACION: " + organizacion3);
                        System.out.println("CONTACTO: " + telefono3);
                    } else {
                        System.out.println("numero no encontrado");
                    }
                }
                case 3 -> {
                    System.out.println("eliminar contacto escribir palabra ***SI*** ");
                    SI = scanner.nextLine();
                    if (SI == null) {
                        nombre1 = null;
                        nombre2 = null;
                        nombre3 = null;

                        telefono1 = 0;
                        telefono2 = 0;
                        telefono3 = 0;

                        organizacion1 = null;
                        organizacion2 = null;
                        organizacion3 = null;
                    }
                }
                case 4 -> {
                    condicion = false;
                    System.out.println("****SALISTES DEL PROGRAMA****");
                }
                default -> JOptionPane.showMessageDialog(null, "OPCION NO ENCONTRADA");
            }
    }
}
}



