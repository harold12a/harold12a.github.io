package TallerCiclos;

import java.util.Scanner;

public class Punto5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final int terminar= 4;
        for (; ;) {
            System.out.println("menu de usuario"+"\n"
                    +" 1 -capturar nombre"+"\n"
                    +" 2 -saludar persona"+"\n"
                    +" 3 -salir del sistema"+"\n"
                    +"para terminar ingresa el "+terminar);
            int num = scanner.nextInt();
            if(num==terminar){
                break;
            }

            
        }
    }
}
