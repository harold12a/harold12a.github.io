package TallerCiclos;

import javax.swing.*;
import java.util.Scanner;

public class Punto7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;
        boolean condicion = true;
        int i;
        int Nrequerido;

        String nombre1= null,nombre2= null,nombre3= null,nombre4= null,nombre5= null;
        String placa1 = null,placa2 = null,placa3= null,placa4= null,placa5= null;
        String marca1= null,marca2= null,marca3= null,marca4= null,marca5= null;
        int contacto1=0,contacto2=0,contacto3=0,contacto4=0,contacto5=0;
        String retiro;
        String consultar;


        while (condicion) {
            opcion = Integer.parseInt(JOptionPane.showInputDialog("""
                    PARQUIADERO EL GUARDIAN\s
                     1- INGRESAR AL PARQUIADERO\s
                     2- RETIRAR VEHICULO\s
                     3- CONSULTAR VEHICULO POR PLACA\s
                     4- SALIR"""));
            switch (opcion) {
                case 1 -> {
                    System.out.println("CUANTOS USUARIOS QUIERES INGRESAR...");
                    Nrequerido = scanner.nextInt();
                    if (Nrequerido <= 5) {
                        for (i = 1; i <= Nrequerido; i++) {
                            if(i==1){
                                scanner.nextLine();
                                System.out.println("USUARIO: ");
                                nombre1 = scanner.nextLine();
                                System.out.println("PLACA: ");
                                placa1 = scanner.nextLine();
                                System.out.println("MARCA: ");
                                marca1 = scanner.nextLine();
                                System.out.println("CONTACTO");
                                contacto1 = scanner.nextInt();
                            }else if(i==2){
                                scanner.nextLine();
                                System.out.println("USUARIO: ");
                                nombre2 = scanner.nextLine();
                                System.out.println("PLACA: ");
                                placa2 = scanner.nextLine();
                                System.out.println("MARCA: ");
                                marca2 = scanner.nextLine();
                                System.out.println("CONTACTO");
                                contacto2 = scanner.nextInt();
                            }else if(i==3){
                                scanner.nextLine();
                                System.out.println("USUARIO: ");
                                nombre3 = scanner.nextLine();
                                System.out.println("PLACA: ");
                                placa3 = scanner.nextLine();
                                System.out.println("MARCA: ");
                                marca3 = scanner.nextLine();
                                System.out.println("CONTACTO");
                                contacto3 = scanner.nextInt();

                            }else if(i==4){
                                scanner.nextLine();
                                System.out.println("USUARIO: ");
                                nombre4 = scanner.nextLine();
                                System.out.println("PLACA: ");
                                placa4 = scanner.nextLine();
                                System.out.println("MARCA: ");
                                marca4 = scanner.nextLine();
                                System.out.println("CONTACTO");
                                contacto4 = scanner.nextInt();
                            }else if(i==5){
                                scanner.nextLine();
                                System.out.println("USUARIO: ");
                                nombre5 = scanner.nextLine();
                                System.out.println("PLACA: ");
                                placa5 = scanner.nextLine();
                                System.out.println("MARCA: ");
                                marca5 = scanner.nextLine();
                                System.out.println("CONTACTO");
                                contacto5 = scanner.nextInt();
                            }
                        }
                        System.out.println("HAS AGREGADO EL MAXIMO DE USUARIOS SOLITADOS...");
                    } else {
                        System.out.println("EL MAXIMO DE USUARIO ES 5 INGRESA UN VALOR INFERIOR A 5...");
                    }
                }
                case 2 -> {
                    System.out.println("RETIRAR VEHIVULO:");
                    System.out.println("INGRESE PLACA PARA EL RETIRO DE SU VEHICULO:");
                    retiro = scanner.nextLine();
                    if(retiro.equals(placa1)){
                        System.out.println(" SU VEHICULO HA SIDO RETIRADO: ");
                        nombre1= null;
                       placa1 = null;
                       marca1 =null;
                       contacto1=0;

                        System.out.println("GRACIAS POR PREFERIRNOS LO ESPERAMOS PRONTAMENTE");
                            }else if(retiro.equals(placa2)){
                        System.out.println(" SU VEHICULO HA SIDO RETIRADO: ");
                         nombre2=null;
                        placa2=null;
                        marca2=null;
                        contacto2=0;
                        System.out.println("GRACIAS POR PREFERIRNOS LO ESPERAMOS PRONTAMENTE");
                    } else if(retiro.equals(placa3)){
                        System.out.println(" SU VEHICULO HA SIDO RETIRADO: ");
                        nombre3 = null;
                         placa3 = null;
                         marca3 = null;
                         contacto3 =0;
                        System.out.println("GRACIAS POR PREFERIRNOS LO ESPERAMOS PRONTAMENTE");
                    }else if(retiro.equals(placa4)){
                        System.out.println(" SU VEHICULO HA SIDO RETIRADO: ");
                         nombre4 = null;
                         placa4 = null;
                         marca4 = null;
                         contacto4 =0;
                        System.out.println("GRACIAS POR PREFERIRNOS LO ESPERAMOS PRONTAMENTE");
                    }else if (retiro.equals(placa5)){
                        System.out.println(" SU VEHICULO HA SIDO RETIRADO: ");
                        nombre5 = null;
                         placa5 = null;
                       marca5 = null;
                       contacto5 =0;
                        System.out.println("GRACIAS POR PREFERIRNOS LO ESPERAMOS PRONTAMENTE");
                    }
                    else {
                                System.out.println("PLACA INCORRECTA INGRESA OTRA PLACA");
                            }

                }
                case 3 -> {
                    System.out.println("BUSQUEDA POR PLACA: ");
                    System.out.println("INGRESE LA PLACA DE SU VEHICULO:");
                    consultar = scanner.nextLine();
                    if(consultar.equals(placa1)){
                        System.out.println("nombre: " + nombre1 + " placa: " + placa1 + " marca: " + marca1+ " contacto: " + contacto1);
                        System.out.println("GRACIAS POR PREFERIRNOS");
                    }else if(consultar.equals(placa2)){
                        System.out.println("nombre: " + nombre2 + " placa: " + placa2 + " marca: " + marca2 + " contacto: " + contacto2);
                        System.out.println("GRACIAS POR PREFERIRNOS");
                    }else if (consultar.equals(placa3)){
                        System.out.println("nombre: " + nombre3 + " placa: " + placa3 + " marca: " + marca3 + " contacto: " + contacto3);
                        System.out.println("GRACIAS POR PREFERIRNOS");
                    }else if (consultar.equals(placa4)){
                        System.out.println("nombre: " + nombre4 + " placa: " + placa4 + " marca: " + marca4 + " contacto: " + contacto4);
                        System.out.println("GRACIAS POR PREFERIRNOS");
                    }else if (consultar.equals(placa5)){
                        System.out.println("nombre: " + nombre5 + "placa: " + placa5 + "marca: " +  marca5 + "contacto: " + contacto5);
                        System.out.println("GRACIAS POR PREFERIRNOS");
                    }
                    else{
                                System.out.println("INGRESE OTRA PLACA");
                            }




                }
                case 4 -> {
                    condicion = false;
                    System.out.println("****SALISTES DEL PROGRAMA****");
                }
                default -> JOptionPane.showMessageDialog(null, "OPCION NO ENCONTRADA");
            }

        }
    }
}






