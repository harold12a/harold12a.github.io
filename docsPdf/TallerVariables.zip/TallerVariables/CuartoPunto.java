package TallerVariables;

import java.util.Scanner;

public class CuartoPunto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("ingrese la capital de su pais:");
        String pais = scanner.nextLine();
        System.out.println("ingrese el pais de su capital: ");
        String capital = scanner.nextLine();



        System.out.println("La ciudad de:  " + pais + " es la capital de:   " +capital);
    }
}
