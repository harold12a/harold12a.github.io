package TallerVariables;

import java.util.Scanner;

public class TercerPunto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("digite su nombre:");
        String nombre = scanner.nextLine();
        System.out.println("digite su apellido: ");
        String apellido = scanner.nextLine();
        System.out.println("ingrese  nombre de su padre : ");
        String nomPadre = scanner.nextLine();
        System.out.println("ingrese nombre de su madre: ");
        String nomMadre = scanner.nextLine();


        System.out.println("yo: " + nombre + "  " + apellido+ " soy hijo de : "+nomMadre+ " y "+nomPadre );
    }
}
