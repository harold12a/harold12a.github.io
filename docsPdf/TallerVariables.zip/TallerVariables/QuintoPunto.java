package TallerVariables;

import java.util.Scanner;

public class QuintoPunto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("digite el nombre de su mascota: ");
        String mascota = scanner.nextLine();
        System.out.println("ingrese tipo de mascota:");
        String tipo = scanner.nextLine();
        System.out.println("digite su nombre completo: ");
        String nombre = scanner.nextLine();
        System.out.println("ingrese la edad de su mascota: ");
        int edad = scanner.nextInt();

        System.out.println("el nombre de mi mascota es:"+mascota+ "\n"+
                " Es un: " +tipo+ "\n"+
                " El cual tiene: "+edad+ " años de edad:"+"\n"+
                nombre+ " es actualmente su dueño"

        );
    }
}
