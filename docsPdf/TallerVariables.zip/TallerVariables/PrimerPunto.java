package TallerVariables;

import java.util.Scanner;

public class PrimerPunto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("digite su nombre:");
        String nombre = scanner.nextLine();
        System.out.println("digite su apellido: ");
        String apellido = scanner.nextLine();
        System.out.println("nombre : "+nombre+  " apellido: "+apellido);

    }
}
