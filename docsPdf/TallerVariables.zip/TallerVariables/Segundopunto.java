package TallerVariables;

import java.util.Scanner;

public class Segundopunto {

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("digite su nombre:");
            String nombre = scanner.nextLine();
            System.out.println("digite su apellido: ");
            String apellido = scanner.nextLine();
            System.out.println("ingrese su edad : ");
            int edad = scanner.nextInt();
            System.out.println("ingrese su estatura ejemplo 1,72: ");
            float estatura = scanner.nextFloat();


            System.out.println("nombre : " + nombre + " apellido: " + apellido+ " edad: "+edad+ " estatura: "+estatura );

        }
    }

